#!/usr/bin/python3
"""NOTE : !!!! Very Important !!!!
need to do follow things first
sudo pip3 install requests
sudo pip3 install -U pytest
or sudo apt-get install -y python3-requests python3-pytest
How to run pytest: py.test-3.4 BMC_Release_Test.py -s 2>&1 | tee test.log
"""
import os, sys, requests
from json import loads
from re import sub, search
from time import sleep, strftime
from atexit import register as trap
from configparser import ConfigParser
from platform import system as os_type
from logging import basicConfig, DEBUG, getLogger, StreamHandler, Formatter

#import self-definition function
sys.path.append('./lib')
from func_zip import zipSpecifyFile
from func_getdevid import get_device_id
from func_wait_reset import waiting_event
from func_resetbmc_api import BMCResetApi
from func_filter_color import colorFilter
from func_power_control import power_control

#global varibles for all function
FAIL_RED = '\033[91mFAIL\033[0m'
PASS_GREEN = '\033[92mPASS\033[0m'
INFO = """

\033[93m[1-2]\033[0m \033[1mUpdate the new firmware for test.\033[0m

\033[1m## Print Argument:\033[0m
================================================================================
 * User Name:        {0}
 * Password:         {1}
 * BMC IPaddr:       {2}
 * Image Path:
   {3}
 * Image FileName:   {4}
 * Preserve Value:   {5}
================================================================================

\033[1m## Print Firmware Info:\033[0m
================================================================================
 * Current BMC FW Version: \033[1m{10}\033[0m \033[93m(OLD)\033[0m
 * Upgrade FW to Version:  \033[1m{9}\033[0m \033[92m(NEW)\033[0m
================================================================================

\033[1m## Print Preserve Value:\033[0m
================================================================================
 * Temporary Data:   {6}
 * Preserve Data:    {7}
 * Preserve Count:   {8}
================================================================================

"""

#record script log and replace print method
loggerlog = os.path.splitext(__file__)[0]+'.log'
basicConfig(filename=loggerlog, level=DEBUG)
logger = getLogger(__name__)
fhandler = StreamHandler()
fhandler.setFormatter(Formatter())
logger.addHandler(fhandler)

#register exit event, remove log color code after exit
trap(colorFilter, [os.path.join(os.getcwd(), 'test.log'), loggerlog])

try:
    #import configuration and define varibles
    config = ConfigParser()
    config.read('test_config.ini')
    COUNTER = 0
    USERNAME, PASSWORD = config.get('UserInfo', 'USERNAME'), config.get('UserInfo', 'PASSWORD')
    BMC_IP, FILE_NAME, ERASE_SECTION_VAL = config.get('Settings', 'BMC_IP'), config.get('Settings', 'FILE_NAME'), config.get('Settings', 'ERASE_SECTION_VAL')
    NEW_VERSION = config.get('Configuration', 'FW_VERSION')
    PKG_NAME, FILE_DIR = os.path.basename(FILE_NAME), os.path.dirname(FILE_NAME)
    PKG_DIR, PKG_TYPE = os.path.join(FILE_DIR, PKG_NAME.split('.')[0]), PKG_NAME.split('.')[1]
    IMAGE_FILE = os.path.join(PKG_DIR, 'rom.ima')
except Exception as err:
    logger.error(str(err))
    assert False, str(err)

#1. BMC Image Check
class TestCheckImageFile(object):
    def test_check_image(self):
        logger.info('\n\n\033[93m[1-1]\033[0m \033[1mCheck the package name should be match name rule.\n\t(e.g. "K880G3_BMC_V000100.ZIP")\033[0m')
        if not search('^\w+_BMC_V\d{6}\.(zip|ZIP)$', PKG_NAME):
            logger.error('Invalid package name, "e.g. "K880G3_BMC_V000100.ZIP"')
            assert False, 'Invalid package name, "e.g. "K880G3_BMC_V000100.ZIP"'

        #extract release package
        if not os.path.isfile(IMAGE_FILE) and os.path.isfile(FILE_NAME):
            logger.debug('\n * Extract package: ' + PKG_NAME)
            zipSpecifyFile(FILE_NAME, 'extract')
        if not os.path.isfile(IMAGE_FILE):
            logger.error('File rom.ima is not found')
            assert False, 'File rom.ima is not found'

        logger.info('\033[1m=> Check package and image file completed.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Check the image in match with naming rule [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True

class TestCheckBMCVersion(object):
    def test_fw_update(self):
        global COUNTER

        if BMC_IP.count('.') != 3:
            logger.error('Invalid BMC IP address')
            assert False, 'Invalid BMC IP address'
        if not ERASE_SECTION_VAL.isdigit() or int(ERASE_SECTION_VAL) > 63:
            logger.error('File rom.ima is not found')
            assert False, 'Preserve value error'

        #preserve value
        preserv_count, tmp_data, value = 0, '', int(ERASE_SECTION_VAL)
        if value == 63:
            preserv_count, tmp_data, preserv_data = 'None', 'None', '{"preserve_config":0,"flash_status":1}'
        else:
            val_list = [1, 2, 4, 8, 16, 32]
            test_list = ['"boot"', '"conf"', '"root"', '"osimage"', '"www"', '"ast2500e\\u0002"']
            for index, each_val in enumerate(val_list):
                if value&each_val == each_val:
                    test = test_list[index]
                    if preserv_count == 0:
                        tmp_data = tmp_data+test
                    else:
                        tmp_data = tmp_data+','+test
                    preserv_count = preserv_count+1
            preserv_data = '{"preserve_config":0,"flash_status":2,"section_count":%s,"section_names":[%s]}' % (str(preserv_count), tmp_data)

        get_result, data_before = get_device_id(BMC_IP, USERNAME, PASSWORD)
        OLD_VERSION = 'V'+data_before['BMC_VER']
        if not get_result:
            logger.error('Try to connect to device failed')
            assert False, 'Try to connect to device failed'
        if sub(r'[^(\d{1,2}\.){1,2}\d{1,2}]','',NEW_VERSION) == sub(r'[^(\d{1,2}\.){1,2}\d{1,2}]','',OLD_VERSION):
            logger.error('Updated FW version the same as device: '+OLD_VERSION)
            assert False, 'Updated FW version the same as device: '+OLD_VERSION

        logger.debug(INFO.format(USERNAME, PASSWORD, BMC_IP, PKG_DIR, 'rom.ima', ERASE_SECTION_VAL, tmp_data, preserv_data, str(preserv_count), NEW_VERSION, OLD_VERSION))

        #create session (post)
        logger.info("\n\033[1m## Create Session\033[0m")
        headers = {
            'Cache-Control': 'no-cache',
            'Content-Type': 'application/x-www-form-urlencoded',
            'postman-token': 'a5bee417-5686-53d2-6476-1128149281c4',
        }
        data = {'password': PASSWORD,'username': USERNAME}
        response = requests.post('http://{}/api/session'.format(BMC_IP), headers=headers, data=data)
        SESSION_HEADER = 'Cookie: '+ response.headers['set-cookie'].split(';')[0]
        CSRFTOKEN = loads(response.text)['CSRFToken']

        logger.info("Login Session Info:")
        logger.debug(' * '+SESSION_HEADER)
        logger.debug(" * Token: " + CSRFTOKEN + '\n\n')

        if os.system('bash requests_from_API.sh -p {0} -u {1} -H {2} -f \'{3}\' -d \'{4}\' -s \'{5}\' -t {6}'.format(PASSWORD, USERNAME, BMC_IP, IMAGE_FILE, preserv_data, SESSION_HEADER, CSRFTOKEN)) != 0:
            logger.error('Update BMC FW failed...')
            assert False, 'Update BMC FW failed...'

        #wait for BMC buffered 
        #wait for BMC system off: waiting_event(300, opposite=True)
        if not waiting_event(300):
            logger.error('Wait for BMC timeout')
            assert False, 'Wait for BMC buffered timeout'
        sleep(60)

        #step 6, reset BMC
        logger.info("\n\033[1m## Reset BMC test\033[0m")
        logger.info("\nThis will take \033[1mfew time\033[0m, please be patient.")
        if not BMCResetApi(BMC_IP, USERNAME, PASSWORD):
            logger.error("Reset BMC Fail...")
            assert False, 'Reset BMC failed...'

        #wait for BMC reset
        if not waiting_event(300):
            logger.error('Reset BMC timeout')
            assert False, 'Reset BMC timeout'

        logger.info('\033[1m=> BMC firmware update successfully.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Update the new firmware [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True

    def test_check_fw_version(self):
        logger.info('\n\033[93m[1-3]\033[0m \033[1mCheck firmware version via "Get Device ID" command.\033[0m')
        get_result, data_updated = get_device_id(BMC_IP, USERNAME, PASSWORD)
        if not get_result:
            logger.error('Device ID is unavailable')
            assert False, 'Device ID is unavailable'
        OLD_VERSION = 'V'+data_updated['BMC_VER']
        if OLD_VERSION != NEW_VERSION:
            logger.error('FW Version error, new: {0} current: {1}'.format(NEW_VERSION, OLD_VERSION))
            assert False, 'FW Version error, new: {0} current: {1}'.format(NEW_VERSION, OLD_VERSION)

        logger.info('\033[1m=> Verify firmware version in match.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Check firmware version [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True

#2. BMC Interfaces  
class TestRMCPInterface(object):
    def test_RMCP(self):
        logger.info('\n\033[93m[2-2]\033[0m \033[1mExecute the command "Get Device ID" to verify RMCP work normally.\033[0m')
        if not get_device_id(BMC_IP, USERNAME, PASSWORD, 'lan')[0]:
            logger.error('\033[1m=> Get Device ID command executed [\033[0m{}\033[1m]\033[0m'.format(FAIL_RED))
            assert False, 'execute Get Device ID command failed'
        logger.info('\033[1m=> Get Device ID command executed successfully.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Verify RMCP interface at work [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True

class TestRMCPPlusInterface(object):
    def test_RMCP_plus(self):
        logger.info('\n\033[93m[2-3]\033[0m \033[1mExecute the command "Get Device ID" to verify RMCP+ work normally.\033[0m')
        if not get_device_id(BMC_IP, USERNAME, PASSWORD)[0]:
            logger.error('\033[1m=> Get Device ID command executed [\033[0m{}\033[1m]\033[0m'.format(FAIL_RED))
            assert False, 'execute Get Device ID command failed'
        logger.info('\033[1m=> Get Device ID command executed successfully.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Verify RMCP+ interface at work [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True

