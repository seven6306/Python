import json,requests

#requests from RESTful API
#step 1, create session (post)
print("\n##### Create Session")
headers = {
    'Cache-Control': 'no-cache',
    'Content-Type': 'application/x-www-form-urlencoded',
    'postman-token': 'a5bee417-5686-53d2-6476-1128149281c4',
}
data = {'password': PASSWORD,'username': USERNAME}
response = requests.post('http://{}/api/session'.format(BMC_IP), headers=headers, data=data)
SESSION_HEADER = response.headers['set-cookie'].split(';')[0]
CSRFTOKEN = json.loads(response.text)['CSRFToken']

#step2~step5 require below listed two arguments
print("Login Session Info:")
print('Cookie: ' + SESSION_HEADER)
print("Token: " + CSRFTOKEN)

#step 2, set to flash mode (put)
print("\n##### Set To Flash Mode")
headers = {
    'Cache-Control': 'no-cache',
    'X-CSRFTOKEN': CSRFTOKEN,
    'Cookie': SESSION_HEADER,
}
response = requests.put('http://{}/api/maintenance/flash'.format(BMC_IP), headers=headers)
RESPONSE_CODE = response.status_code
print("Status Code: "+str(RESPONSE_CODE))
if RESPONSE_CODE != 200:
    print("Set Fail...")
    assert False, 'Set to flash mode failed...'

#step 3, upload image file (post)
print("\n##### Upload Image")
headers = {
    'Cookie': SESSION_HEADER, #this is unconfirm varibles
    'Cache-Control': 'no-cache',
    'X-CSRFTOKEN': CSRFTOKEN,
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,zh-TW;q=0.8,zh;q=0.5,en;q=0.3',
    'Content-Type': 'multipart/form-data;'
    'Connection': 'keep-alive'
    'X-Requested-With': 'XMLHttpRequest'
}
files = {'fwimage': ('rom.ima', open(IMAGE_FILE, 'rb'), 'application/octet-stream')}
response = requests.post('http://{}/api/maintenance/firmware'.format(BMC_IP), headers=headers, files=files)
response_dic = json.loads(response.text)
cc_code = response_dic['cc']
print("Return CC code: "+str(cc_code))
if [ '.'+str(cc_code)+'.' != '. 0 .':
    print('Upload Image Fail...')
    assert False, 'Upload Image failed...'

#step 4, verification (get)
print("\n##### GET Image Verification Result")
headers = {
    'Cache-Control': 'no-cache',
    'X-CSRFTOKEN': CSRFTOKEN,
    'Cookie': SESSION_HEADER, #this is unconfirm varibles
}
response = requests.get('http://{}/api/maintenance/firmware/verification'.format(BMC_IP), headers=headers)
print("Verification data: "+response.text)

#step 5, flash (put)
print("\n##### Perform Image Flash")
headers = {
    'Cache-Control': 'no-cache',
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Content-Type': 'application/json',
    'Connection': 'keep-alive',
    'X-CSRFTOKEN': CSRFTOKEN,
    'Cookie': SESSION_HEADER, #this is unconfirm varibles
}
data = json.loads(preserv_data)
response = requests.post('http://{}/api/maintenance/firmware/upgrade'.format(BMC_IP), headers=headers, data=data)

#step 6, reset BMC (post)
print("\n##### Reset BMC")
headers = {
    'Cookie': SESSION_HEADER, #this is unconfirm varibles
    'Cache-Control': 'no-cache',
    'X-CSRFTOKEN': CSRFTOKEN,
    'Content-Type': 'application/json',
    'Content-Length': 0,
}
response = requests.post('http://{}/api/maintenance/firmware/reset'.format(BMC_IP), headers=headers)
#if '.'+response.text+'.' != '.{ }.':
if os.system('ipmitool -H {0} -I lanplus -U {1} -P {2} raw 0x06 0x01'.format(BMC_IP, USERNAME, PASSWORD)) == 0:
    print("Reset BMC Fail...")
    assert False, 'Reset BMC failed...'
print("FW Flash Complete. Resetting BMC...")
assert True