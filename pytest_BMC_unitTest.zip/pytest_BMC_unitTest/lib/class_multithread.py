#!/usr/bin/python3

from os import system
from time import sleep
from threading import Thread, active_count

Usage = """
Usage:

## define object
thread_1 = MultiProcess('automation', 0)
thread_2 = MultiProcess('keyControl', 5)

## object instantiation 
thread_1.start()
thread_2.start()

## example means that if threading number not
## little than 2, program will hold on this part.
isAlive('lt', 2)
"""

class MultiProcess(Thread):
    def __init__(self, action, delay, cmd):
        Thread.__init__(self)
        self.action = action
        self.delay = delay
        self.cmd = cmd
    def run(self):
        ProcessAction(self.action, self.delay, self.cmd)
    def help(self):
        print(Usage)

def ProcessAction(action, delay, cmd):
    sleep(delay)
    if action == 'cmd':
        #1st thread action
        result_code = system(cmd)
        return(result_code)
    elif action == 'timer':
        #2nd thread action
        print('Starting control automation...')

def isAlive(logic=None, threadNum=0):
    while(True):
        if logic == 'lt':
            if active_count() < threadNum:
                break
        elif logic == 'gt':
            if active_count() > threadNum:
                break
        sleep(0.5)
