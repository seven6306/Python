#!/usr/bin/python3

from apt.cache import Cache
from os import walk, chdir, system
from zipfile import ZipFile, ZIP_DEFLATED
from os.path import join, dirname, basename, splitext, isfile

USAGE = """
Usage: [ FileName ] [ Output ] [ Action ]
Action:
        -c, --compress,   create a new archive
        -e, --extract,    extract files from an archive
e.g., 
      python3 func_7zip.py /home/user/example.7z /home/user/example -c
      python3 func_7zip.py /home/user/example.zip --compress
"""

def p7zipSpecifyFile(p7zName, act):
    cache = Cache()
    p7zip = cache['p7zip-full']
    if not p7zip.is_installed or act not in ['a', 'x'] or not p7zName:
        return(False)
    if not system('7z {0} {1}'.format(act, p7zName)):
        return(False)
    return(True)

def zipSpecifyFile(zipName='default.zip', action='compress', fullPath=''):
    if action == 'compress':
        path = basename(fullPath) + '\\'
        chdir(dirname(fullPath))
        with ZipFile(zipName, 'w', ZIP_DEFLATED) as zipf:
            for root, dir, files in walk(path):
                for each_file in files:
                    file_path = join(root, each_file)
                    zipf.write(file_path)
                    #print(r'Compressing {0} to {1}'.format(file_path, zipName))
            return(join(dirname(fullPath), zipName))
    elif action == 'extract':
        with ZipFile(zipName) as zipf:
            if fullPath != '':
                zipf.extractall(fullPath)
            else:
                zipf.extractall(dirname(zipName))

if __name__ == '__main__':
    from sys import argv
    if len(argv) > 2:
        what, tmp_list1 = '', []
        act_opt = ['-c', '-e', '--compress', '--extract']
        tmp_list2 = act_opt+[argv[0]]
        [tmp_list1.append(e) for e in argv if e in act_opt]
        [argv.remove(e) for e in argv if e in tmp_list2]
        if tmp_list1[0] in ['-c', '--compress']:
            what = 'a;compress'
        elif tmp_list1[0] in ['-e', '--extract']:
            what = 'e;extract'
        for each_file in argv:
            if isfile(each_file):
                if splitext(each_file) == '.7z':
                    p7zipSpecifyFile(each_file, what.split(';')[0])
                elif splitext(each_file) == '.zip':
                    zipSpecifyFile(each_file, what.split(';')[1])
    else:
        print(USAGE)
