#!/usr/bin/python3

from apt.cache import Cache

USAGE = """
Usage: [ Packages ] [ Options ]
Option:
        --update,     Retrieve new lists of packages
        --upgrade,    Perform an upgrade
        --list-pass,  List item with install sucessfully
        --list-fail,  List item with install failure
"""
PASS_GREEN = '\033[92mPASS\033[0m'
FAIL_RED = '\033[91mFAIL\033[0m'

def apt_get(action):
    try:
        if action not in ['--update', '--upgrade']:
            raise TypeError
        cache = Cache()
        print('Getting start to apt-get {}, it will take few minutes...'.format(action.replace('--','')))
        if action == '--update':
            cache.update()
        elif action == '--upgrade':
            cache.upgrade()
        cache.open(None)
        print(PASS_GREEN+': '+'apt-get '+action.replace('--','')+' success.')
        return(True)
    except Exception as err:
        print(FAIL_RED+': '+str(err))
        return(False)

def apt_get_install(pkgList=[], argv_list=[]):
    try:
        listPASS, listFAIL = [], []
        print('\nPackage list: ', pkgList, '\n')
        for each_pkg in pkgList:
            cache = Cache()
            pkg = cache[each_pkg]
            if pkg.is_installed:
                print('Package: {} is already installed.'.format(each_pkg))
                listFAIL.append(each_pkg)
            else:
                pkg.mark_install()
                try:
                    cache.commit()
                    listPASS.append(each_pkg)
                except Exception as inserr:
                    listFAIL.append(each_pkg)
                    print(str(inserr)+': Permission denied')
        for each_ins in listPASS:
            print('Package: {} is success installed'.format(each_ins))
        if '--list-pass' in argv_list:
            print('\n'+PASS_GREEN+' list: ', listPASS)
        if '--list-fail' in argv_list:
            print('\n'+FAIL_RED+' list: ', listFAIL)
    except Exception as pkgerr:
        print('No Package ERROR: '+str(pkgerr))

if __name__ == '__main__':
    from sys import argv
    if len(argv) > 1:
        act_list, argv_list, packages = [], [], argv
        [act_list.append(a) for a in ['--update', '--upgrade'] if a in argv]
        [argv_list.append(a) for a in ['--list-pass', '--list-fail'] if a in argv]
        #ignored argv[0]: script name and options
        [packages.remove(a) for a in [argv[0], '--list-pass', '--list-fail', '--update', '--upgrade'] if a in packages]
        if act_list != []:
            [apt_get(e) for e in act_list]
        if packages != []:
            apt_get_install(packages, argv_list)
    else:
        print(USAGE)
