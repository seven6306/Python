#!/usr/bin/python3

import requests
from time import sleep
from json import loads

def waitAPIbuffer(host, retry):
    for i in range(retry):
        try:
            s = requests.session()
            res = s.get('http://{}/api'.format(host))
            rdata = loads(res.text)
            print(' * Get web service response successfully.')
            sleep(2)
            return(True)
        except requests.exceptions.RequestException:
            for j in range(30):
                print('{}\r'.format(' '*75), end='')
                print('Wait 30 seconds for web service buffering.'+'.'*j+'\r', end='')
                sleep(1)
            print('{}\r'.format(' '*75), end='')
        except Exception as err:
            print(str(err))
        finally:
            s.close()
    return(False)

if __name__ == '__main__':
    from sys import argv
    if len(argv) > 2:
        if argv[2].isdigit():
            waitAPIbuffer(argv[1], int(argv[2]))
            raise SystemExit(0)
    print('Invalid argument value: [ host_addr ] [ retry_times ]')
    raise SystemExit(10)
