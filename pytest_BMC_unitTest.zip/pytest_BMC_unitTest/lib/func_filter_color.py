#!/usr/bin/python3

from re import sub
from os import remove
from os.path import isfile

def colorFilter(file):
    tmplist, faillist = [], []
    if not isinstance(file, list):
        tmplist.append(file)
        file = tmplist
    for each_file in file:
        try:
            if not isfile(each_file):
                raise IOError
            with open(each_file) as rf:
                rdata = rf.read().split('\n')
            remove(each_file)
            with open(each_file, 'a') as wf:
                for each_line in rdata:
                    wf.write(sub(r'\x1b(\[.*?[@-~]|\].*?(\x07|\x1b\\))', '', each_line)+'\n')
        except Exception as err:
            print(str(err))
            faillist.append(each_file)
            pass
    return(faillist)

if __name__ == '__main__':
    from sys import argv
    if len(argv) > 2 and '-f' in argv:
        colorFilter(argv[2])
    else:
        print('Usage: [ -f filename ]')
