#!/usr/bin/python3
#Format curl to requests to reference site: https://curl.trillworks.com/

import requests
from json import loads
from var_config import *
from func_session_api import create_session

def get_fwinfo(host=''):
    if not host:
        host = BMC_IP
    SESSION_HEADER_, CSRFTOKEN, cookies = create_session()
    cookies['refresh_disable'] = '1'

    headers = {
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Referer': 'http://{}/'.format(host),
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'X-CSRFTOKEN': CSRFTOKEN,
    }

    res = requests.get('http://{}/api/firmware-info'.format(host), headers=headers, cookies=cookies)
    data = loads(res.text)
    return(data)

if __name__ == '__main__':
    from sys import argv
    if len(argv) > 2 and '-h' in argv:
        print(get_fwinfo(argv[2]))
        raise SystemExit(0)
    print('Invalid argument value: [ -h host_ip ]')
    raise SystemExit(10)
