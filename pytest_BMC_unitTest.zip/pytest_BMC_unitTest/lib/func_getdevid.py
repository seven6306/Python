#!/usr/bin/python3

from os import popen

times = 0
Info = """

Raw Data = {8}

## Print BMC Info:
=================================================
 * Device ID                  : {0}
 * Device Revision            : {1}
 * Firmware Revision          : {2}
 * IPMI Version               : {3}
 * Aux Firmware Rev Info      : {4}
 * Inventec Firmware Version  : {5}.{6}.{7}
=================================================

"""

def get_device_id(IPAddr='', user='', passwd='', intfc='lanplus'):
    global times
    for i in range(3):
        try:
            raw_data = popen('ipmitool -H {0} -I {3} -U {1} -P {2} raw 0x06 0x01'.format(IPAddr, user, passwd, intfc)).readlines()[0].replace('\n','').split(' ')
            raw_data_str = ''.join(str(e)+' ' for e in raw_data)
            #convert raw data hex to dec
            FW_REV_P1, FW_REV_P2, AUX_REV = int(raw_data[3]), int(raw_data[4]), int(raw_data[12])
            if FW_REV_P1 < 10:
                FW_REV_P1 = '0'+str(FW_REV_P1)
            if FW_REV_P2 < 10:
                FW_REV_P2 = '0'+str(FW_REV_P2)
            if AUX_REV < 10:
                AUX_REV = '0'+str(AUX_REV)
            BMC_FW_REV = str(FW_REV_P1) + '.' + str(FW_REV_P2)
            data = {
                'DEV_ID': int(raw_data[1], 16),
                'DEV_REV': int(raw_data[2]),
                'IPMI_VER': str(int(raw_data[5]))+'.0',
                'BMC_FW_REV': BMC_FW_REV,
                'BMC_AUX_REV': str(AUX_REV),
                'BMC_VER': str(FW_REV_P1)+str(FW_REV_P2)+str(AUX_REV),
            }
            print(Info.format(data['DEV_ID'], data['DEV_REV'], data['BMC_FW_REV'], data['IPMI_VER'], data['BMC_AUX_REV'], str(FW_REV_P1), str(FW_REV_P2), str(AUX_REV), raw_data_str))
            return(True, data)
        except Exception as err:
            times = times+1
            print('Execute command time out, retry '+str(times))
    return(False, {})

if __name__ == '__main__':
    from sys import argv
    if len(argv) < 3:
        print('Invalid argument')
        raise SystemExit(1)
    get_device_id(argv[1], argv[2], argv[3])
