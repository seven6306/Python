#!/usr/bin/python3

from os import system
from var_config import *

def power_control(action):
    try:
        act = code_dict[action]
        status_code = system('ipmitool -H {0} -I lanplus -U {1} -P {2} raw {3}'.format(BMC_IP, USERNAME, PASSWORD, act))
        return(status_code)
    except Exception:
        print('Action require to follow below listed dict:')
        print(code_dict)
        return(255)
