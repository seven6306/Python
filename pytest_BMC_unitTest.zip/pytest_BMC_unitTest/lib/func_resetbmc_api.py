#!/usr/bin/python3

import requests
from os import popen
from sys import argv
from json import loads
from time import sleep
from func_session_api import create_session

argv_num = len(argv)

def BMCResetApi(host='', user='', passwd='', s_info=[]):
    if argv_num > 3 or s_info == []:
        SESSION_HEADER_, CSRFTOKEN, cookies = create_session()
        SESSION_HEADER = 'Cookie: ' + SESSION_HEADER_
    else:
        SESSION_HEADER, CSRFTOKEN = s_info[0], s_info[1]
    #execute curl command to request from API
    timer = 0
    for i in range(3):
        res = popen("curl -L -s --request POST \
              --url \'http://{0}/api/maintenance/reset\' \
              --header \'{1}\' \
              --header \'Cache-Control: no-cache\' \
              --header \'X-CSRFTOKEN: {2}\' \
              --header \'Content-Type: application/json\' \
              --header \'Content-Length: 0\'".format(host, SESSION_HEADER, CSRFTOKEN)).read()
        sleep(20)
        if '.'+res+'.' == '.{ }.':
            print('BMC reset starting...\n')
            return(True)
        timer = timer+1
        print('Response: '+res)
        print('Reset failed, retry round '+str(timer))
    return(False)

if __name__ == '__main__':
    if argv_num > 3:
        if BMCResetApi(argv[1], argv[2], argv[3]):
            print('Reset BMC OK')
    else:
        print('Invalid argument value')
        raise SystemExit(10)
