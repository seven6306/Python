#!/usr/bin/python3

import requests
from json import loads
from var_config import *

def create_session():
    try:
        #create session
        headers = {
            'Cache-Control': 'no-cache',
            'Content-Type': 'application/x-www-form-urlencoded',
            'postman-token': 'a5bee417-5686-53d2-6476-1128149281c4',
        }
        data = {
            'password': USERNAME, 'username': PASSWORD,
        }
        response = requests.post('http://{}/api/session'.format(BMC_IP), headers=headers, data=data)

        SESSION_HEADER = response.headers['set-cookie'].split(';')[0]
        CSRFTOKEN = loads(response.text)['CSRFToken']
        cookies = {
            SESSION_HEADER.split('=')[0]: SESSION_HEADER.split('=')[1],
        }
        return(SESSION_HEADER, CSRFTOKEN, cookies)
    except:
        return('', '', {})