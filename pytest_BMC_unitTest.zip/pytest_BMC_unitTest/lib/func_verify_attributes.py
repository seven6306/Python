#!/usr/bin/python3

from re import sub
from os import system
from var_config import *
from socket import inet_aton
from func_getdevid import get_device_id

def checkIPaddr(Addr):
    #check IP address format
    try:
        Addr2, tmp_Addr = '', []
        if Addr.count('.') != 3:
            raise Exception
        inet_aton(Addr)
        [tmp_Addr.append(int(i)) for i in Addr.split('.')]
        Addr2 = ''.join('{0}{1}.'.format(Addr2, str(j)) for j in tmp_Addr)[:-1]
        if system('ping -q {} -c 1 >> /dev/null 2>&1'.format(Addr2)) != 0:
            raise Exception
        return(True, Addr2)
    except:
        return(False, 'Invalid BMC IP address')

def checkFWver(new, act):
    #check firmware version
    get_result, data_ID = get_device_id(BMC_IP, USERNAME, PASSWORD)
    OLD_VERSION = 'V'+data_ID['BMC_VER']
    if not get_result:
        return(False, 'Try to connect to device failed')
    if act == 0:
        if sub(r'[^(\d{1,2}\.){1,2}\d{1,2}]','',new) == sub(r'[^(\d{1,2}\.){1,2}\d{1,2}]','',OLD_VERSION):
            return(False, 'Updated FW version the same as device: '+OLD_VERSION, OLD_VERSION)
    elif act == 1:
        if sub(r'[^(\d{1,2}\.){1,2}\d{1,2}]','',new) != sub(r'[^(\d{1,2}\.){1,2}\d{1,2}]','',OLD_VERSION):
            return(False, 'FW Version error, new: {0} current: {1}'.format(new, OLD_VERSION), OLD_VERSION)
    return(True, '', OLD_VERSION)
