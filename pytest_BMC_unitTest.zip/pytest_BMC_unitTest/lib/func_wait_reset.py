#!/usr/bin/python3

from os import system
from time import sleep
from var_config import *

def waiting_event(s=300, opposite=False):
    COUNTER, reset_result, r_code = 0, 1, 0
    if opposite:
        r_code = 256
    while(reset_result != r_code):
        reset_result = system('ipmitool -H {0} -I lanplus -U {1} -P {2} raw 0x06 0x01 > /dev/null 2>&1'.format(BMC_IP, USERNAME, PASSWORD))
        print('                           \r', end='')
        print('Waiting for reset.'+'.'*COUNTER+'\r', end='')
        COUNTER = COUNTER + 1
        if COUNTER > int(s/5):
            return(False)
        sleep(5)
    return(True)
