#!/usr/bin/python3

#check execute version is python3
import os
from sys import version_info

EXEC_VER = version_info[0]

if EXEC_VER < 3:
    os.system('printf "ERROR: Must be using \033[1;31mpython3\033[0m to execute script.\n"')
    raise SystemExit(255)

#public module for each script use
import requests
from sys import argv
from json import loads
from pytest import mark
from shutil import rmtree
from re import sub, search
from time import sleep, strftime
from atexit import register as trap
from configparser import ConfigParser
from platform import system as os_type
from logging import basicConfig, DEBUG, getLogger, StreamHandler, Formatter

#import self-definition function
from func_verify_attributes import *
from func_getdevid import get_device_id
from func_wait_reset import waiting_event
from func_resetbmc_api import BMCResetApi
from func_filter_color import colorFilter
from func_session_api import create_session
from func_buffered_api import waitAPIbuffer
from func_power_control import power_control
from func_firmwareinfo_api import get_fwinfo
from func_7zip import zipSpecifyFile, p7zipSpecifyFile

#global varibles for all function
LOG_LIST = []
FAIL_RED = '\033[91mFAIL\033[0m'
PASS_GREEN = '\033[92mPASS\033[0m'
PWD = os.getcwd()
LS_ALL = os.listdir()

#record script log and replace print method
basicConfig(filename='debug.log', level=DEBUG)
logger = getLogger(__name__)
fhandler = StreamHandler()
fhandler.setFormatter(Formatter())
logger.addHandler(fhandler)

#register exit event, remove log color code after exit
for each_log in LS_ALL:
    if search('.*\.log$', each_log):
        LOG_LIST.append(os.path.join(os.getcwd(), each_log))
trap(colorFilter, LOG_LIST)
trap(rmtree, '__pycache__')

try:
    #import configuration and define varibles
    config = ConfigParser()
    config.read('test_config.ini')
    USERNAME, PASSWORD = config.get('UserInfo', 'USERNAME'), config.get('UserInfo', 'PASSWORD')
    BMC_IP, FILE_NAME, ERASE_SECTION_VAL = config.get('Settings', 'BMC_IP'), config.get('Settings', 'FILE_NAME'), config.get('Settings', 'ERASE_SECTION_VAL')
    NEW_VERSION = config.get('Configuration', 'FW_VERSION')
    PKG_NAME, FILE_DIR = os.path.basename(FILE_NAME), os.path.dirname(FILE_NAME)
    PKG_DIR, PKG_TYPE = os.path.join(FILE_DIR, PKG_NAME.split('.')[0]), PKG_NAME.split('.')[1]
    IMAGE_FILE = os.path.join(PKG_DIR, 'rom.ima')
except Exception as err:
    logger.error(str(err))
    assert False, str(err)
