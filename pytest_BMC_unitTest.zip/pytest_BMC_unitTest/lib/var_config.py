#!/usr/bin/python3

from configparser import ConfigParser

config = ConfigParser()
config.read('test_config.ini')

BMC_IP = config.get('Settings', 'BMC_IP')
USERNAME = config.get('UserInfo', 'USERNAME')
PASSWORD = config.get('UserInfo', 'PASSWORD')

code_dict = {
    'ColdReset': '0x06 0x02',
    'WarmReset': '0x06 0x03',
    'ChassisReset': '0x00 0x02 0x03',
    'ChassisUp': '0x00 0x02 0x01',
    'ChassisDown': '0x00 0x02 0x00',
    'ChassisCycle': '0x00 0x02 0x02',
}

if __name__ == '__main__':
    print(locals())
