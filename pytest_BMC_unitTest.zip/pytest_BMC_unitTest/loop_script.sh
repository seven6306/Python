#!/bin/bash

RED='\033[1;31m'
GREEN='\033[1;32m'
NC='\033[0m'
PYSCRIPT=''
RETRY_TIME=10
BMC_IP=`grep "BMC_IP = " test_config.ini | awk '{print $3}'`
USERNAME=`grep "USERNAME = " test_config.ini | awk '{print $3}'`
PASSWORD=`grep "PASSWORD = " test_config.ini | awk '{print $3}'`

while [ "$1" != "" ]; do
    case $1 in
        -t) shift
            round=$1;;
        -f) shift
            PYSCRIPT=$1;;
        * ) printf "Usage: [ -t exec_round ] [ -f Pytest_script ]\n"
            exit 1;;
    esac
    shift
done

[ `echo $round | grep -cE '^[0-9]+$'` -eq 0 ] && printf "Usage: [ -t exec_round ]\n" && exit 1
[ ! -f $PYSCRIPT ] && printf "Usage: [ -f Pytest_script ]\n" && exit 2

for i in `seq 1 $round`
do
    FW_VERSION=`python3 lib/func_getdevid.py $BMC_IP $USERNAME $PASSWORD  | grep -oP "(\d{2}\.){2}\d{2}" | sed 's,\.,,g'`
    if [ "$FW_VERSION" = "005200" ]; then
        NEW_VERSION=005400
        sed -i 's,V005200,V005400,g' test_config.ini
    else
        NEW_VERSION=005200
        sed -i 's,V005400,V005200,g' test_config.ini
    fi
    printf "\n * Currently Firmware Version:  ${RED}V$FW_VERSION${NC}\n * Upgrade to Firmware Version: ${GREEN}V$NEW_VERSION${NC}\n\n"
    py.test-3.4 -s $PYSCRIPT 2>&1 | tee -a output_report.log
    printf "\n ############################## test round: $i ############################## \n\n" | tee -a output_report.log
    python3 lib/func_buffered_api.py $BMC_IP $RETRY_TIME
done
