#!/bin/bash

BMC_IP=""
username=""
password=""
SESSION_HEADER=""
CSRFTOKEN=""
image_file=""
preserv_data=""
execute_part=0

function finish_event
{
    printf "\n * Clear temp file \"response.json\"\n\n" && rm -f response.json
}
function Usage
{
    more << EOF
Usage:
    require:  [ -u username ] [ -p password ] [ -H BMC_IP ] [ -f image_file ] [ -d preserv_data ]
    optional: [ -s session_header ] [ -t token ]
e.g.,
    bash requests_from_API.sh \\
      -p ADMIN -u ADMIN \\
      -H 10.6.75.59 \\
      -f /home/iec-fwtest/AS60G1_BMC_V005400/rom.ima \\
      -d '{"preserve_config":0,"flash_status":1}' \\
      -s 'Cookie: QSESSIONID=caa3014acd0a2ab0e2W7auZXEOfFRQ' \\
      -t SXNdqmzs
EOF
    return 0
}
function bmcfwupdate
{
    [ "$SESSION_HEADER" = "" -o "$CSRFTOKEN" = "" ] && local execute_part=1
    if [ $execute_part -eq 1 ]; then
        #step 1, create session
        printf "\n##### Create Session\n"
        [ -f response.json ] && rm -f response.json
        sleep 2
        curl -i -L -s --request POST \
          --url "http://$BMC_IP/api/session" \
          --header 'Cache-Control: no-cache' \
          --header 'Content-Type: application/x-www-form-urlencoded' \
          --header 'postman-token: a5bee417-5686-53d2-6476-1128149281c4' \
          --data "password=$password&username=$username" > response.json

        SESSION_HEADER=`grep -Po "Cookie: QSESSIONID=\w{30}" response.json`
        CSRFTOKEN=`cat response.json | grep -oE 'CSRFToken": "\w.*"' | awk -F\" '{print $3}'`

        printf "Login Session Info:\n"
        printf "$SESSION_HEADER\n"
        printf "Token: $CSRFTOKEN\n"
    fi

    #step 2, set to flash mode
    printf "\n##### Set To Flash Mode\n"
    RESPONSE_CODE=`curl -L -s -w "%{http_code}" --request PUT \
      --url "http://$BMC_IP/api/maintenance/flash" \
      --header 'Cache-Control: no-cache' \
      --header "X-CSRFTOKEN: $CSRFTOKEN" \
      --header "$SESSION_HEADER"`
    printf "Status Code: $RESPONSE_CODE\n"
    if [ "$RESPONSE_CODE" != "200" ];then
        printf "Set Fail...\n"
        exit 255
    fi
    
    
    #step 3, upload image file
    printf "\n##### Upload Image\n"
    image_name=${image_file##*/}
    RES=`curl -L -s --request POST \
      --url "http://$BMC_IP/api/maintenance/firmware" \
      --header "$SESSION_HEADER" \
      --header 'Cache-Control: no-cache' \
      --header "X-CSRFTOKEN: $CSRFTOKEN" \
      --header 'Accept-Encoding: gzip, deflate, br' \
      --header 'Accept-Language: en-US,zh-TW;q=0.8,zh;q=0.5,en;q=0.3' \
      --header 'Content-Type: multipart/form-data;' \
      --header 'Connection: keep-alive' \
      --header 'X-Requested-With: XMLHttpRequest' \
      -F "fwimage=@$image_file;type=application/octet-stream;filename=$image_name" --compressed`
    tmp=${RES#*cc\":}
    cc_code=${tmp%\}*}
    printf "Return CC code:$cc_code\n"
    if [ ".$cc_code." != ". 0 ." ];then
        printf "Upload Image Fail...\n"
        exit 255
    fi    
    

    #step 4, verification
    printf "\n##### GET Image Verification Result\n"
    RESPONSE=`curl -L -s --request GET \
      --url "http://$BMC_IP/api/maintenance/firmware/verification" \
      --header 'Cache-Control: no-cache' \
      --header "X-CSRFTOKEN: $CSRFTOKEN" \
      --header "$SESSION_HEADER"`
    printf "Verification data: $RESPONSE\n"

    
    #step 5, flash
    printf "\n##### Perform Image Flash\n"
    RES=`curl -L -s --request PUT \
      --url "http://$BMC_IP/api/maintenance/firmware/upgrade" \
      --header 'Cache-Control: no-cache' \
      --header 'Accept-Encoding: gzip, deflate, sdch' \
      --header 'Content-Type: application/json' \
      --header 'Connection: keep-alive' \
      --header "X-CSRFTOKEN: $CSRFTOKEN" \
      --header "$SESSION_HEADER" \
      --data "$preserv_data"`
    tmp=${RES#*flash_status\":}}
    tmp=${tmp#* }
    
    printf "\n##### Flash Progress %%\n"
    while [ true ]
    do
        sleep 1 > /dev/null
        RES=`curl -L -s --request GET \
          --url "http://$BMC_IP/api/maintenance/firmware/flash-progress" \
          --header 'Cache-Control: no-cache' \
          --header 'Accept-Encoding: gzip, deflate, sdch' \
          --header "X-CSRFTOKEN: $CSRFTOKEN" \
          --header 'Connection: keep-alive' \
          --header "$SESSION_HEADER"`        
        tmp=${RES#*progress\":}}
        tmp=${tmp#*\"}
        percentage=${tmp%\",*}
        b=#$b
        percentage=`echo $percentage | awk '{print $1}'`
        printf "Progress:[%-80s]%s\r" $b "$percentage"
        chkstr=${percentage%.*}
        if [ "$chkstr" = "Completed" ];then
            break
        fi
    done
    echo

    if [ $execute_part -eq 1 ]; then
        #step 6, reset BMC
        printf "\n##### Reset BMC\n"    
        RES=`curl -L -s --request POST \
          --url "http://$BMC_IP/api/maintenance/reset" \
          --header "$SESSION_HEADER" \
          --header 'Cache-Control: no-cache' \
          --header "X-CSRFTOKEN: $CSRFTOKEN" \
          --header 'Content-Type: application/json' \
          --header 'Content-Length: 0'`
        if [ ".$RES." != ".{ }." ];then
            printf "Reset BMC Fail...\n"
            exit 255
        fi
    fi
    printf "\nFW Flash Complete. Resetting BMC...\n"
    exit 0
}

while [ "$1" != "" ]; do
    case $1 in
        -H) shift
            BMC_IP=$1;;
        -u) shift
            username=$1;;
        -p) shift
            password=$1;;
        -s) shift
            SESSION_HEADER=$1;;
        -t) shift
            CSRFTOKEN=$1;;
        -f) shift
            image_file=$1;;
        -d) shift
            preserv_data=$1;;
        * ) Usage
            exit 1;;
    esac
    shift
done

for each_var in "$username" "$password" "$BMC_IP" "$image_file" "$preserv_data"
do   [ "$each_var" = "" ] && Usage && exit 0
done

more << EOF

## Print FW Update Info:
================================================================================
 * CsrfToken:     $CSRFTOKEN
 * SessionHeader: $SESSION_HEADER
 * Data:          $preserv_data
 * Image Path:    $image_file
================================================================================

EOF

trap finish_event EXIT

bmcfwupdate
