#!/usr/bin/python3
"""
packages = pip.get_installed_distributions()
p = packages[0]
p.project_name 
p.version
p.egg_name
p.location
"""
import os,sys

exec_ver = sys.version_info[0]

#check executing version is python3
if exec_ver < 3:
    os.system('printf "ERROR: Must be using \033[1;31mpython3\033[0m to execute script.\n"')
    raise SystemExit(253)

#check executing identification is root
if os.getuid() != 0:
    print("ERROR: Need root permission, try \033[91m'sudo python3 setup.py'\033[0m")
    raise SystemExit(254)

sys.path.append('./lib')

from apt.cache import Cache
from func_verify_attributes import checkIPaddr
from func_apt_install import apt_get, apt_get_install

#check internet connection
if not checkIPaddr('8.8.8.8')[0]:
    print("ERROR: Require Internet, \033[91mconnection fail\033[0m")
    raise SystemExit(255)

PASS_list, FAIL_list, TMP_list = [], [], []
py_module = ['pip', 'pytest', 'requests', 'pytest-html']
apt_requirements = ['p7zip-full', 'python3-pip', 'python3-pytest', 'python3-requests']

print('\n##### Setup Test Requrements Package:')

while(True):
    ans = input('After this operation will start to install required package of test.\nDo you want to continue? [Y/n] ')
    if ans in ['y', 'Y']:
        break
    elif ans in ['n', 'N']:
        raise SystemExit(0)

print('\n'+'='*75)

#apt-get install
apt_get('--update')
apt_get_install(apt_requirements)

#while pip has been installed, import pip module
from pip import main as pip_main
from pip import get_installed_distributions

#check if module exists or pip install
for each_mod in py_module[1:-1]:
    try:
        __import__(each_mod)
    except ImportError:
        print('Starting to pip3 install '+each_mod)
        pip_main(['install', each_mod])

pip_main(['install', py_module[-1]])

#check package
cache = Cache()
p7zip = cache[apt_requirements[0]]
if p7zip.is_installed:
    PASS_list.append(apt_requirements[0])
else:
    FAIL_list.append(apt_requirements[0])

for each_mod in py_module[0:-1]:
    print('Test to import module "'+each_mod+'"')
    try:
        __import__(each_mod)
        print(' => module '+each_mod+' import \033[92msuccess\033[0m.\n')
        PASS_list.append(each_mod)
    except ImportError:
        print(' => module '+each_mod+' import \033[91mfailure\033[0m.\n')
        FAIL_list.append(each_mod)

#search pytest-html package location
pip_loc1, pip_loc2 = '/usr/local/lib/', '/usr/lib/'
pip_dir1, pip_dir2 = os.listdir(pip_loc1), os.listdir(pip_loc2)
[TMP_list.append(os.path.join(pip_loc1, each_path)) for each_path in pip_dir1 if 'python3' in os.path.join(pip_loc1, each_path)]
[TMP_list.append(os.path.join(pip_loc2, each_path)) for each_path in pip_dir2 if 'python3' in os.path.join(pip_loc2, each_path)]  
for each_dir in TMP_list:
    if os.path.isdir(os.path.join(each_dir, 'dist-packages')):
        if 'pytest_html' in os.listdir(os.path.join(each_dir, 'dist-packages')):
            PASS_list.append(py_module[-1])
            break

if py_module[-1] not in PASS_list:
    FAIL_list.append(py_module[-1])

print('='*75)
print(' \033[92m*****\033[0m Package Satisfied:\n\t', PASS_list, '\n')
print(' \033[91m*****\033[0m Package Dissatisfied:\n\t', FAIL_list, '\n')

if len(FAIL_list) != 0:
    print('Oops! Some packages could not be installed.\n')
    raise SystemExit(256)
else:
    print('Congratulations!! you may start to Test.\n')
