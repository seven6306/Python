#!/usr/bin/python3
#1. BMC Image Check:
#    1-1: Check the package name should be match name rule

import sys
sys.path.append('./lib')
from public_module import *

class TestCheckImageFile(object):
    @mark.order1
    def test_check_image(self):
        logger.debug('\n\n\033[93m[1-1]\033[0m \033[1mCheck the package name should be match name rule.\n\t(e.g. "K880G3_BMC_V000100.ZIP")\033[0m')
        if not search('^\w+_BMC_V\d{6}\.(zip|ZIP)$', PKG_NAME):
            logger.error('Invalid package name, "e.g. "K880G3_BMC_V000100.ZIP"')
            assert False, 'Invalid package name, "e.g. "K880G3_BMC_V000100.ZIP"'

        #extract release package
        if not os.path.isfile(IMAGE_FILE) and os.path.isfile(FILE_NAME):
            logger.debug('\n * Extract package: ' + PKG_NAME)
            ZIP_EXT = os.path.splitext(FILE_NAME)[1]
            if ZIP_EXT == '.zip':
                zipSpecifyFile(FILE_NAME, 'extract')
            elif ZIP_EXT == '.7z':
                p7zipSpecifyFile(FILE_NAME, 'x')
        if not os.path.isfile(IMAGE_FILE):
            logger.error('File rom.ima is not found')
            assert False, 'File rom.ima is not found'

        logger.info('\033[1m=> Check package and image file completed.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Check the image in match with naming rule [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True
