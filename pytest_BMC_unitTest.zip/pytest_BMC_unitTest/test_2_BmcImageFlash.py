#!/usr/bin/python3
#1. BMC Image Check:
#    2-1: Update the new firmware for test
#    2-2: Check firmware version via "Get Device ID" command.

import sys
sys.path.append('./lib')
from public_module import *

INFO = """

\033[93m[1-2]\033[0m \033[1mUpdate the new firmware for test.\033[0m

\033[1m## Print Argument:\033[0m
================================================================================
 * User Name:        {0}
 * Password:         {1}
 * BMC IPaddr:       {2}
 * Image Path:
   {3}
 * Image FileName:   {4}
 * Preserve Value:   {5}
================================================================================

\033[1m## Print Firmware Info:\033[0m
================================================================================
 * Current BMC FW Version: \033[1m{10}\033[0m \033[93m(OLD)\033[0m
 * Upgrade FW to Version:  \033[1m{9}\033[0m \033[92m(NEW)\033[0m
================================================================================

\033[1m## Print Preserve Value:\033[0m
================================================================================
 * Temporary Data:   {6}
 * Preserve Data:    {7}
 * Preserve Count:   {8}
================================================================================

"""

class TestBmcImageFlash(object):
    @mark.order1
    def test_fw_update(self):

        BOOLEAN_ANS, ERRMSG = checkIPaddr(BMC_IP)
        if not BOOLEAN_ANS:
            logger.error(ERRMSG)
            assert False, ERRMSG
        if not os.path.isfile(IMAGE_FILE):
            logger.error('File rom.ima is not found')
            assert False, 'File rom.ima is not found'
        if not ERASE_SECTION_VAL.isdigit() or int(ERASE_SECTION_VAL) > 63:
            logger.error('Invalid preserve value')
            assert False, 'Preserve value error'

        #preserve value
        preserv_count, tmp_data, value = 0, '', int(ERASE_SECTION_VAL)
        if value == 63:
            preserv_count, tmp_data, preserv_data = 'None', 'None', '{"preserve_config":0,"flash_status":1}'
        else:
            val_list = [1, 2, 4, 8, 16, 32]
            test_list = ['"boot"', '"conf"', '"root"', '"osimage"', '"www"', '"ast2500e\\u0002"']
            for index, each_val in enumerate(val_list):
                if value&each_val == each_val:
                    test = test_list[index]
                    if preserv_count == 0:
                        tmp_data = tmp_data+test
                    else:
                        tmp_data = tmp_data+','+test
                    preserv_count = preserv_count+1
            preserv_data = '{"preserve_config":0,"flash_status":2,"section_count":%s,"section_names":[%s]}' % (str(preserv_count), tmp_data)

        BOOLEAN_ANS, ERRMSG, OLD_VERSION = checkFWver(NEW_VERSION, 0)
        if not BOOLEAN_ANS:
            logger.error(ERRMSG)
            assert False, ERRMSG

        logger.debug(INFO.format(USERNAME, PASSWORD, BMC_IP, PKG_DIR, 'rom.ima', ERASE_SECTION_VAL, tmp_data, preserv_data, str(preserv_count), NEW_VERSION, OLD_VERSION))

        #create session (post)
        logger.info("\n\033[1m## Create Session\033[0m")
        SESSION_HEADER_, CSRFTOKEN, cookies = create_session()
        SESSION_HEADER = 'Cookie: ' + SESSION_HEADER_

        logger.debug("Login Session Info:")
        logger.debug(' * '+SESSION_HEADER)
        logger.debug(" * Token: " + CSRFTOKEN + '\n\n')

        if os.system('bash requests_from_API.sh -p {0} -u {1} -H {2} -f \'{3}\' -d \'{4}\' -s \'{5}\' -t {6}'.format(PASSWORD, USERNAME, BMC_IP, IMAGE_FILE, preserv_data, SESSION_HEADER, CSRFTOKEN)) != 0:
            logger.error('Update BMC FW failed...')
            assert False, 'Update BMC FW failed...'

        #wait for BMC buffered 
        #wait for BMC system off: waiting_event(300, opposite=True)
        if not waiting_event(300):
            logger.error('Wait for BMC timeout')
            assert False, 'Wait for BMC buffered timeout'
        sleep(60)

        #step 6, reset BMC
        logger.info("\n\033[1m## Reset BMC test\033[0m")
        logger.info("\nThis will take \033[1mfew time\033[0m, please be patient.")
        if not BMCResetApi(BMC_IP, USERNAME, PASSWORD):
            logger.error("Reset BMC Fail...")
            assert False, 'Reset BMC failed...'

        #wait for BMC reset
        if not waiting_event(300):
            logger.error('Reset BMC timeout')
            assert False, 'Reset BMC timeout'

        logger.info('\033[1m=> BMC firmware update successfully.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Update the new firmware [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True

    @mark.order2
    def test_check_fw_version(self):
        logger.debug('\n\033[93m[1-3]\033[0m \033[1mCheck firmware version via "Get Device ID" command.\033[0m')
        BOOLEAN_ANS, ERRMSG, OLD_VERSION = checkFWver(NEW_VERSION, 1)
        if not BOOLEAN_ANS:
            logger.error(ERRMSG)
            assert False, ERRMSG

        logger.info('\033[1m=> Verify firmware version in match.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Check firmware version [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True
