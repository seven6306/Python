#!/usr/bin/python3
#2. BMC Interfaces:
#    2-2: Execute the cmd(ipmitool -H <ip> -U <username> -P <password> raw 0x06 0x01) to verify RMCP work normally.

import sys
sys.path.append('./lib')
from public_module import *

class TestRmcpInterface(object):
    @mark.order1
    def test_RMCP(self):
        logger.debug('\n\033[93m[2-2]\033[0m \033[1mExecute the command "Get Device ID" to verify RMCP work normally.\033[0m')
        if not get_device_id(BMC_IP, USERNAME, PASSWORD, 'lan')[0]:
            logger.error('\033[1m=> Get Device ID command executed [\033[0m{}\033[1m]\033[0m'.format(FAIL_RED))
            assert False, 'execute Get Device ID command failed'
        logger.info('\033[1m=> Get Device ID command executed successfully.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Verify RMCP interface at work [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True
