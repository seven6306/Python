#!/usr/bin/python3
#3. BMC Firmware Flash:
#    3-1: Open the "cmd" and enter the Yafuflash(./Yafuflash -H <ip> -U <username> -P <password> -full -nw xxx.ima) command to update BMC

import sys
sys.path.append('./lib')
from public_module import *

INFO = """

\033[93m[3-1]\033[0m \033[1mUpgrade BMC firmware via tool "Yafuflash".\033[0m

\033[1m## Print Argument:\033[0m
================================================================================
 * User Name:        {0}
 * Password:         {1}
 * BMC IPaddr:       {2}
 * Image File:  
    {3}
================================================================================

\033[1m## Print Firmware Info:\033[0m
================================================================================
 * Current BMC FW Version: \033[1m{4}\033[0m \033[93m(OLD)\033[0m
 * Upgrade FW to Version:  \033[1m{5}\033[0m \033[92m(NEW)\033[0m
================================================================================

"""

class TestBmcFirmwareFlash(object):
    @mark.order1
    def test_BMC_upgrade(self):
        Yafu_tool = os.path.abspath('tools/Yafuflash')
        Yafu_dir = os.path.dirname(Yafu_tool)

        logger.info('\n * Starting veriy each argument values.\n')
        if not os.path.isfile(Yafu_tool):
            logger.error('Tool "{}" is not found'.format(Yafu_tool))
            assert False, 'Tool "Yafuflash" is not found'

        #check argument values
        if not os.path.isfile(IMAGE_FILE):
            logger.error('File rom.ima is not found')
            assert False, 'File rom.ima is not found'
        BOOLEAN_ANS, ERRMSG = checkIPaddr(BMC_IP)
        if not BOOLEAN_ANS:
            logger.error(ERRMSG)
            assert False, ERRMSG
        BOOLEAN_ANS, ERRMSG, OLD_VERSION = checkFWver(NEW_VERSION, 0)
        if not BOOLEAN_ANS:
            logger.error(ERRMSG)
            assert False, ERRMSG

        logger.debug(INFO.format(USERNAME, PASSWORD, BMC_IP, IMAGE_FILE, OLD_VERSION, NEW_VERSION))

        #modify tool execute permission
        logger.debug('\n * Modify tool \033[1m"Yafuflash\033[0m" permission to \033[1m777\033[0m (-rxwrxwrxw)\n')
        os.chmod(Yafu_tool, 0o777)

        #invoke tool Yafuflash to upgrade fw (change to directory loaction of Yafuflash)
        logger.debug(' * Change currently work directory to \033[1m'+Yafu_dir+'\033[0m')
        os.chdir(Yafu_dir)
        if os.system('echo y | ./Yafuflash -isi -nw -ip {0} -u {1} -p {2} -full -d 0x01 {3}'.format(BMC_IP, USERNAME, PASSWORD, IMAGE_FILE)) != 0:
            logger.error('Update BMC FW failed...')
            assert False, 'Update BMC FW failed...'
        logger.debug('\n * Back to work directory \033[1m'+PWD+'\033[0m\n')
        os.chdir(PWD)

        #wait for reset and web api response 
        if not waitAPIbuffer(BMC_IP, 10):
            logger.error('Reset BMC timeout')
            assert False, 'Reset BMC timeout'

        logger.info('\033[1m=> BMC firmware update successfully.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Upgrade firmware via tool "Yafuflash" [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True

    @mark.order2
    def test_checkWeb_fwver(self):
        logger.debug('\n\033[93m[3-4]\033[0m \033[1mCheck firmware version via web API.\033[0m')
        FW_INFO = get_fwinfo()
        FW_VER = FW_INFO['fw_ver']

        logger.info('\033[1m=> Verify firmware version in match.\033[0m')
        logger.debug('\n\n\033[1m ***** [{0}] Check firmware version via web [\033[0m{1}\033[1m] *****\033[0m'.format(strftime('%Y-%m-%d %H:%M:%S'), PASS_GREEN))
        assert True


